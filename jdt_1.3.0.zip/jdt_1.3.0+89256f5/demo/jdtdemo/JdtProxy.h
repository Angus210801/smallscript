#ifndef JDTWRAPPER_H
#define JDTWRAPPER_H

#include <cstdio>
#include "json.hpp"
#include "ChildProcess.h"

class JdtProxy
{
public:
  JdtProxy();
  virtual ~JdtProxy();

public:
  bool start(const std::string& command);

  bool recvMsg(nlohmann::json& msg);
  bool sendMsg(const nlohmann::json& msg);

private:
  std::string locateJdtBinary();
  std::string currentProgramFilePath();
  std::string currentProgramDirectoryPath();


private:
  ChildProcess jdt;
  std::string  waitAck;
};

#endif //JDTWRAPPER_H
