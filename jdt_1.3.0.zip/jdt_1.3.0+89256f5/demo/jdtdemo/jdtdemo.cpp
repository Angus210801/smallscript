#include <cstdio>

#include "json.hpp"
#include "CLI.h"
#include "JdtProxy.h"
#include "JdtMsg.h"

using Mutex = std::recursive_mutex;
using Guard = std::lock_guard<Mutex>;

CLI cli;
JdtProxy jdt;
JdtMsg::Dispatcher dispatcher;

std::map<JdtMsg::DongleId, JdtMsg::Dongle> dongles;
JdtMsg::DongleId curDongle = JdtMsg::INVALID_DONGLE_ID;

std::map<JdtMsg::DongleId, std::map<JdtMsg::PairingId, JdtMsg::Pairing>> pairingList;

// The dispatcher callbacks run in the main thread, while the CLI callbacks
// run in a different thread. We use this mutex to make sure they don't step
// on each other's toes.
Mutex mutex;

std::string
formatPrompt(JdtMsg::DongleId id)
{
  char buf[256] = "> ";

  if(id != JdtMsg::INVALID_DONGLE_ID)
    sprintf(buf, "%ld:%s> ", id, dongles[id].name.substr(6).c_str());

  return buf;
}

void
updatePrompt(JdtMsg::DongleId id)
{
  cli.setPrompt(formatPrompt(id));
}

void
showPrompt()
{
  printf("%s", formatPrompt(curDongle).c_str());
  fflush(stdout);
}

void
hidePrompt()
{
  printf("\r                                 \r");
  fflush(stdout);
}

// Many of the callbacks do not use the parameter, which is OK.
// Disable the warning for the callbacks.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

bool
onCmdHelp(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  printf("\n");
  printf("Commands:\n");
  printf("\n");
  printf("  help                     Show this help.\n");
  printf("  quit                     Quit the program.\n");
  printf("\n");
  printf("  dl                       List attached dongles.\n");
  printf("  sel <dongle id>          Select specified dongle.\n");
  printf("\n");
  printf("  search [ <seconds> ]     Start search for specified number of seconds. Default: 0 (forever)\n");
  printf("  nosearch                 Stop search.\n");
  printf("\n");
  printf("  pair <BT addr>           Pair with specified BT address.\n");
  printf("  unpair <pairing id>      Delete the specified pairing in dongle.\n");
  printf("\n");
  printf("  con <pairing id>         Connect specified pairing id.\n");
  printf("  dis <pairing id>         Disconnect specified pairing id.\n");
  printf("\n");
  printf("  pl                       Show cached pairing list.\n");
  printf("  gpl                      Get pairing list from dongle and update cache.\n");
  printf("  cpl                      Clear pairing list in dongle.\n");
  printf("\n");


  return false;
}

bool
onCmdQuit(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(!jdt.sendMsg(JdtMsg::Encode::quit()))
    printf("Could not send message to jdt..?!\n");

  return true;
}

bool
onCmdDongleList(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  printf("%4s  %-20s  %-20s  %s\n", "ID", "Name", "Serial number", "Firmware Version");
  printf("%4s  %-20s  %-20s  %s\n", std::string(4, '-').c_str(), std::string(20, '-').c_str(), std::string(20, '-').c_str(), std::string(16, '-').c_str());

  for(auto& x: dongles)
    printf("%4ld  %-20s  %-20s  %s\n", x.second.id, x.second.name.c_str(), x.second.serial.c_str(), x.second.version.c_str());

  return false;
}

bool
onCmdSelect(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(cmd.size() > 1) {
    try {
      JdtMsg::DongleId id = std::stoi(cmd[1]);

      if(id != curDongle) {
        auto it = dongles.find(id);

        if(it != dongles.end()) {
          curDongle = id;
          updatePrompt(curDongle);
        } else {
          printf("No dongle with ID %ld\n", id);
        }
      }
    }
    catch(std::exception& e) {
      printf("Invalid dongle ID: %s\n", cmd[1].c_str());
    }
  } else {
    printf("Please specify a dongle ID\n");
  }

  return false;
}

bool
onCmdSearch(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  int seconds = 0;

  if(cmd.size() > 1) {
    try {
      seconds = std::stoi(cmd[1]);
      if(seconds < 0 || seconds > 255) {
        printf("Search time must be in the range [0-255] seconds!\n");
        return false;
      }
    }
    catch(std::exception& e) {
      printf("Please specify a number of seconds (or nothing, default is 0)\n");
      return false;
    }
  }

  if(!jdt.sendMsg(JdtMsg::Encode::searchStart(curDongle, seconds)))
    printf("Could not send message to jdt..?!\n");

  return false;
}

bool
onCmdNoSearch(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(!jdt.sendMsg(JdtMsg::Encode::searchStop(curDongle)))
    printf("Could not send message to jdt..?!\n");

  return false;
}

bool
onCmdPair(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(cmd.size() > 1) {
    if(!jdt.sendMsg(JdtMsg::Encode::pair(curDongle, cmd[1])))
      printf("Could not send message to jdt..?!\n");
  } else
    printf("Usage: pair <BT address>\n");

  return false;
}

bool
onCmdUnPair(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(cmd.size() > 1) {
    try {
      JdtMsg::PairingId pairingId = std::stoi(cmd[1]);

      if(!jdt.sendMsg(JdtMsg::Encode::unpair(curDongle, pairingId)))
        printf("Could not send message to jdt..?!\n");
    }
    catch(std::exception& e) {
      printf("Please specify a pairing id\n");
      return false;
    }
  } else
    printf("Usage: unpair <pairing id>\n");

  return false;
}

bool
onCmdConnect(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(cmd.size() > 1) {
    try {
      JdtMsg::PairingId pairingId = std::stoi(cmd[1]);

      if(!jdt.sendMsg(JdtMsg::Encode::connect(curDongle, pairingId)))
        printf("Could not send message to jdt..?!\n");
    }
    catch(std::exception& e) {
      printf("Please specify a pairing id\n");
      return false;
    }
  } else
    printf("Usage: connect <pairing id>\n");

  return false;
}

bool
onCmdDisconnect(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(cmd.size() > 1) {
    try {
      JdtMsg::PairingId pairingId = std::stoi(cmd[1]);

      if(!jdt.sendMsg(JdtMsg::Encode::disconnect(curDongle, pairingId)))
        printf("Could not send message to jdt..?!\n");
    }
    catch(std::exception& e) {
      printf("Please specify a pairing id\n");
      return false;
    }
  } else
    printf("Usage: disconnect <pairing id>\n");

  return false;
}

bool
onCmdPairingList(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  printf("%4s  %-20s  %-20s  %s\n", "ID", "Name", "BT Address", "Status");
  printf("%4s  %-20s  %-20s  %s\n", std::string(4, '-').c_str(), std::string(20, '-').c_str(), std::string(20, '-').c_str(), std::string(12, '-').c_str());

  for(auto& p: pairingList[curDongle])
    printf("%4d  %-20s  %-20s  %s\n", p.second.id, p.second.name.c_str(), p.second.address.c_str(), p.second.connected ? "CONNECTED" : "DISCONNECTED");

  return false;
}

bool
onCmdGetPairingList(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(!jdt.sendMsg(JdtMsg::Encode::getPairingList(curDongle)))
    printf("Could not send message to jdt..?!\n");

  return false;
}

bool
onCmdClearPairingList(const CLI::ParsedCommand& cmd)
{
  Guard lk(mutex);

  if(!jdt.sendMsg(JdtMsg::Encode::clearPairingList(curDongle)))
    printf("Could not send message to jdt..?!\n");

  return false;
}

void
onCliDone()
{
  Guard lk(mutex);

  jdt.sendMsg(JdtMsg::Encode::quit());
}

void
onCliError(CLI::ErrorType type, const std::string& msg, const std::string& line)
{
  Guard lk(mutex);

  switch(type) {
  case CLI::ErrorType::ParseError:
    printf("Parse error: %s\n", msg.c_str());
    break;
  case CLI::ErrorType::UnknownCommand:
    printf("Unknown command: %s\n", line.c_str());
    break;
  }
}

#pragma GCC diagnostic pop

void
onMsgReady(const std::string& jdtVersion)
{
  printf("Connected to jdt %s\n", jdtVersion.c_str());
}

void
onMsgAttach(const JdtMsg::Dongle& dongle)
{
  printf("ATTACH %ld: %-20s %-20s %s\n", dongle.id, dongle.name.c_str(), dongle.serial.c_str(), dongle.version.c_str());

  dongles[dongle.id] = dongle;

  if(curDongle == JdtMsg::INVALID_DONGLE_ID) {
    curDongle = dongle.id;
    updatePrompt(curDongle);
  }
}

void
onMsgDetach(JdtMsg::DongleId id)
{
  printf("DETACH %ld: %-20s %-20s %s\n", id, dongles[id].name.c_str(), dongles[id].serial.c_str(), dongles[id].version.c_str());

  dongles.erase(id);
  pairingList.erase(id);

  if(id == curDongle) {
    if(!dongles.empty())
      curDongle = dongles.begin()->first;
    else
      curDongle = JdtMsg::INVALID_DONGLE_ID;

    updatePrompt(curDongle);
  }
}

void
onMsgPairingList(const JdtMsg::DongleId dongleId, const std::vector<JdtMsg::Pairing>& pairings)
{
  pairingList.erase(dongleId);

  for(auto& p: pairings)
    pairingList[dongleId][p.id] = p;
}

void
onMsgError(const std::string& msg, const std::string& reason)
{
  printf("Could not process message: %s\n", msg.c_str());
  printf("Reason: %s\n", reason.c_str());
}

void
onMsgConnectionAttempt(JdtMsg::DongleId id, const std::string& address)
{
  printf("%ld:%s: Connection attempt from %s\n", id, dongles[id].name.substr(6).c_str(), address.c_str());
}

void
onMsgConnected(JdtMsg::DongleId id, JdtMsg::PairingId pairingId)
{
  printf("%ld:%s: %s is now connected\n", id, dongles[id].name.substr(6).c_str(), pairingList[id][pairingId].name.c_str());
}

void
onMsgConnectTimeout(JdtMsg::DongleId id, JdtMsg::PairingId pairingId)
{
  printf("%ld:%s: connect %s timeout!\n", id, dongles[id].name.substr(6).c_str(), pairingList[id][pairingId].name.c_str());
}

void
onMsgDisconnected(JdtMsg::DongleId id, JdtMsg::PairingId pairingId)
{
  printf("%ld:%s: %s is now disconnected\n", id, dongles[id].name.substr(6).c_str(), pairingList[id][pairingId].name.c_str());
}

void
onMsgDisconnectTimeout(JdtMsg::DongleId id, JdtMsg::PairingId pairingId)
{
  printf("%ld:%s disconnect %s time out!\n", id, dongles[id].name.substr(6).c_str(), pairingList[id][pairingId].name.c_str());
}

void
onMsgPairingComplete(JdtMsg::DongleId id, JdtMsg::PairingId pairingId)
{
  printf("%ld:%s pairing %d with %s created\n", id, dongles[id].name.substr(6).c_str(), pairingId, pairingList[id][pairingId].name.c_str());
}

void
onMsgPairingTimeout(JdtMsg::DongleId id, const std::string& address)
{
  printf("%ld:%s: pairing timeout, address %s\n", id, dongles[id].name.substr(6).c_str(), address.c_str());
}

void
onMsgPairingRejected(JdtMsg::DongleId id, const std::string& address)
{
  printf("%ld:%s: pairing rejected, address %s\n", id, dongles[id].name.substr(6).c_str(), address.c_str());
}

void
onMsgSearchResult(JdtMsg::DongleId id, const std::string& address, const std::string& name, JdtMsg::SignalStrength signalStrength)
{
  printf("%ld:%s: search result: %16s %-20s  signal: %d\n", id, dongles[id].name.substr(6).c_str(), address.c_str(), name.c_str(), signalStrength);
}

void
onMsgSearchComplete(JdtMsg::DongleId id)
{
  printf("%ld:%s: search complete!\n", id, dongles[id].name.substr(6).c_str());
}

void
onMsgDongleList(const std::vector<JdtMsg::Dongle>& dongleList)
{
  for(auto& dongle: dongleList)
    printf("%ld: %-20s %-20s %s\n", dongle.id, dongle.name.c_str(), dongle.serial.c_str(), dongle.version.c_str());
}

void
onMsgAck(const std::string& messageId)
{
  printf("ACK: %s\n", messageId.c_str());
}

void
onMsgNack(const std::string& messageId, size_t reasonId, const std::string& reason)
{
  printf("NACK: %s: %s (%lu)\n", messageId.c_str(), reason.c_str(), static_cast<unsigned long>(reasonId));
}

void
initCli()
{
  cli.setDoneCallback(onCliDone);
  cli.setErrorCallback(onCliError);

  cli.addCommand("help",             onCmdHelp);
  cli.addCommand("quit",             onCmdQuit);

  cli.addCommand("dl",               onCmdDongleList);
  cli.addCommand("sel",              onCmdSelect);

  cli.addCommand("search",           onCmdSearch);
  cli.addCommand("nosearch",         onCmdNoSearch);

  cli.addCommand("pair",             onCmdPair);
  cli.addCommand("unpair",           onCmdUnPair);

  cli.addCommand("con",              onCmdConnect);
  cli.addCommand("dis",              onCmdDisconnect);

  cli.addCommand("pl",               onCmdPairingList);
  cli.addCommand("gpl",              onCmdGetPairingList);
  cli.addCommand("cpl",              onCmdClearPairingList);

  cli.start();
}

void
initDispatcher()
{
  dispatcher.setReadyCallback(onMsgReady);
  dispatcher.setAttachCallback(onMsgAttach);
  dispatcher.setDetachCallback(onMsgDetach);
  dispatcher.setConnectionAttemptCallback(onMsgConnectionAttempt);
  dispatcher.setConnectedCallback(onMsgConnected);
  dispatcher.setConnectTimeoutCallback(onMsgConnectTimeout);
  dispatcher.setDisconnectedCallback(onMsgDisconnected);
  dispatcher.setDisconnectTimeoutCallback(onMsgDisconnectTimeout);
  dispatcher.setPairingCompleteCallback(onMsgPairingComplete);
  dispatcher.setPairingTimeoutCallback(onMsgPairingTimeout);
  dispatcher.setPairingRejectedCallback(onMsgPairingRejected);
  dispatcher.setSearchResultCallback(onMsgSearchResult);
  dispatcher.setSearchCompleteCallback(onMsgSearchComplete);

  dispatcher.setDongleListCallback(onMsgDongleList);
  dispatcher.setPairingListCallback(onMsgPairingList);

  dispatcher.setAckCallback(onMsgAck);
  dispatcher.setNackCallback(onMsgNack);

  dispatcher.setErrorCallback(onMsgError);
}


int
main(int argc, char* argv[])
{
  std::string command;

  if(argc > 1)
    command = argv[1];

  if(jdt.start(command)) {
    nlohmann::json msg;

    initDispatcher();
    initCli();

    while(jdt.recvMsg(msg)) {
      Guard lk(mutex);

      hidePrompt();
      dispatcher.dispatch(msg);
      showPrompt();
    }
  } else
    printf("Could not start jdt..\n");
}