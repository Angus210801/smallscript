#ifndef JDTMSG_H
#define JDTMSG_H

#include <string>
#include "json.hpp"

namespace JdtMsg {

using DongleId       = long;
using PairingId      = int16_t;
using SignalStrength = int8_t;

const DongleId INVALID_DONGLE_ID = -1;

namespace Encode {

nlohmann::json  getDongleList();
nlohmann::json  getPairingList(DongleId dongleId);
nlohmann::json  clearPairingList(DongleId dongleId);
nlohmann::json  searchStart(DongleId dongleId, uint8_t seconds);
nlohmann::json  searchStop(DongleId dongleId);
nlohmann::json  pair(DongleId dongleId, const std::string& address);
nlohmann::json  unpair(DongleId dongleId, PairingId pairingId);
nlohmann::json  connect(DongleId dongleId, PairingId pairingId);
nlohmann::json  disconnect(DongleId dongleId, PairingId pairingId);

nlohmann::json  quit();

} // namespace Encode

struct Dongle
{
  DongleId     id;
  std::string  name;
  std::string  serial;
  std::string  version;
};

struct Pairing
{
  PairingId   id;
  std::string name;
  std::string address;
  bool        connected;
};

class Dispatcher
{
public:
  using ReadyCallback              = std::function<void(const std::string& jdtVersion)>;
  using AttachCallback             = std::function<void(const Dongle& dongle)>;
  using DetachCallback             = std::function<void(DongleId dongleId)>;
  using ConnectionAttemptCallback  = std::function<void(DongleId dongleId, const std::string& address)>;
  using ConnectedCallback          = std::function<void(DongleId dongleId, PairingId pairingId)>;
  using ConnectTimeoutCallback     = std::function<void(DongleId dongleId, PairingId pairingId)>;
  using DisconnectedCallback       = std::function<void(DongleId dongleId, PairingId pairingId)>;
  using DisconnectTimeoutCallback  = std::function<void(DongleId dongleId, PairingId pairingId)>;
  using PairingCompleteCallback    = std::function<void(DongleId dongleId, PairingId pairingId)>;
  using PairingTimeoutCallback     = std::function<void(DongleId dongleId, const std::string& address)>;
  using PairingRejectedCallback    = std::function<void(DongleId dongleId, const std::string& address)>;
  using SearchResultCallback       = std::function<void(DongleId dongleId, const std::string& address, const std::string& name, SignalStrength signalStrength)>;
  using SearchCompleteCallback     = std::function<void(DongleId dongleId)>;

  using DongleListCallback         = std::function<void(const std::vector<Dongle>& dongles)>;
  using PairingListCallback        = std::function<void(DongleId id, const std::vector<Pairing>& dongles)>;

  using AckCallback                = std::function<void(const std::string& messageId)>;
  using NackCallback               = std::function<void(const std::string& messageId, size_t reasonId, const std::string& reasonText)>;

  using ErrorCallback              = std::function<void(const std::string& msg, const std::string& reason)>;

public:
  void dispatch(const nlohmann::json& msg);

  void setReadyCallback(ReadyCallback cb)                         { readyCb = std::move(cb); }
  void setAttachCallback(AttachCallback cb)                       { attachCb = std::move(cb); }
  void setDetachCallback(DetachCallback cb)                       { detachCb = std::move(cb); }
  void setConnectionAttemptCallback(ConnectionAttemptCallback cb) { connectionAttemptCb = std::move(cb); }
  void setConnectedCallback(ConnectedCallback cb)                 { connectedCb = std::move(cb); }
  void setConnectTimeoutCallback(ConnectedCallback cb)            { connectTimeoutCb = std::move(cb); }
  void setDisconnectedCallback(DisconnectedCallback cb)           { disconnectedCb = std::move(cb); }
  void setDisconnectTimeoutCallback(DisconnectTimeoutCallback cb) { disconnectTimeoutCb = std::move(cb); }
  void setPairingCompleteCallback(PairingCompleteCallback cb)     { pairingCompleteCb = std::move(cb); }
  void setPairingTimeoutCallback(PairingTimeoutCallback cb)       { pairingTimeoutCb = std::move(cb); }
  void setPairingRejectedCallback(PairingRejectedCallback cb)     { pairingRejectedCb = std::move(cb); }
  void setSearchResultCallback(SearchResultCallback cb)           { searchResultCb = std::move(cb); }
  void setSearchCompleteCallback(SearchCompleteCallback cb)       { searchCompleteCb = std::move(cb); }
  void setDongleListCallback(DongleListCallback cb)               { dongleListCb = std::move(cb); }
  void setPairingListCallback(PairingListCallback cb)             { pairingListCb = std::move(cb); }

  void setAckCallback(AckCallback cb)                             { ackCb = std::move(cb); }
  void setNackCallback(NackCallback cb)                           { nackCb = std::move(cb); }

  void setErrorCallback(ErrorCallback cb)                         { errorCb = std::move(cb); }

private:
  void dispatchEvent(const nlohmann::json& msg);
  void dispatchAck(const nlohmann::json& msg);
  void dispatchNack(const nlohmann::json& msg);

private:
  ReadyCallback               readyCb;
  AttachCallback              attachCb;
  DetachCallback              detachCb;
  ConnectionAttemptCallback   connectionAttemptCb;
  ConnectedCallback           connectedCb;
  ConnectTimeoutCallback      connectTimeoutCb;
  DisconnectedCallback        disconnectedCb;
  DisconnectTimeoutCallback   disconnectTimeoutCb;
  PairingCompleteCallback     pairingCompleteCb;
  PairingTimeoutCallback      pairingTimeoutCb;
  PairingRejectedCallback     pairingRejectedCb;
  SearchResultCallback        searchResultCb;
  SearchCompleteCallback      searchCompleteCb;

  PairingListCallback         pairingListCb;
  DongleListCallback          dongleListCb;

  AckCallback                 ackCb;
  NackCallback                nackCb;

  ErrorCallback               errorCb;
};

}
#endif //JDTMSG_H
