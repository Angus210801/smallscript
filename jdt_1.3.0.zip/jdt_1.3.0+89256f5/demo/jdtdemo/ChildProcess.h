#ifndef CHILDPROCESS_H
#define CHILDPROCESS_H

#include <string>
#include <functional>

class ChildProcess
{
public:
  ChildProcess();
  virtual ~ChildProcess();

public:
  bool start(const std::string& cmd);

  bool getLine(std::string& line);
  bool putLine(const std::string& line);

  int  getStatus();

private:
  bool doFork(const std::function<bool()>& childCallback);

private:
  pid_t       pid = -1;
  int         ifd = -1;
  int         ofd = -1;

  bool        waitDone = false;
  int         status = -1;
};

#endif //CHILDPROCESS_H
