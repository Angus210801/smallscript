#include <sstream>

#include "JdtMsg.h"
#include "json.hpp"

using json = nlohmann::json;
using namespace std::literals;

namespace JdtMsg {

namespace Encode {

json
getDongleList()
{
  return {
    {"message-type",      "action"},
    {"message-id",        "get-dongle-list"}
  };
}

json
getPairingList(DongleId dongleId)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "get-pairing-list"},
    {"dongle-id",         dongleId}
  };
}

json
clearPairingList(DongleId dongleId)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "clear-pairing-list"},
    {"dongle-id",         dongleId}
  };
}

json
searchStart(DongleId dongleId, uint8_t seconds)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "search-start"},
    {"dongle-id",         dongleId},
    {"seconds",           seconds}
  };
}

json
searchStop(DongleId dongleId)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "search-stop"},
    {"dongle-id",         dongleId}
  };
}

json
pair(DongleId dongleId, const std::string& address)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "pair"},
    {"dongle-id",         dongleId},
    {"address",           address}
  };
}

json
unpair(DongleId dongleId, PairingId pairingId)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "unpair"},
    {"dongle-id",         dongleId},
    {"pairing-id",        pairingId}
  };
}

json
connect(DongleId dongleId, PairingId pairingId)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "connect"},
    {"dongle-id",         dongleId},
    {"pairing-id",        pairingId}
  };
}

json
disconnect(DongleId dongleId, PairingId pairingId)
{
  return {
    {"message-type",      "action"},
    {"message-id",        "disconnect"},
    {"dongle-id",         dongleId},
    {"pairing-id",        pairingId}
  };
}

json
quit()
{
  return {
    {"message-type",      "action"},
    {"message-id",        "quit"}
  };
}

} // namespace Encode

void
Dispatcher::dispatch(const nlohmann::json& msg)
{
  try {
    auto messageType = msg.at("message-type").get<std::string>();

    if(messageType == "event")
      dispatchEvent(msg);
    else if(messageType == "ack")
      dispatchAck(msg);
    else if(messageType == "nack")
      dispatchNack(msg);
    else {
      if(errorCb)
        errorCb(msg.dump(), "unknown message type: "s + messageType);
    }
  }
  catch(json::exception& e) {
    if(errorCb) {
      std::stringstream ss;
      ss << "JSON error: " << e.what() << " (" << e.id << ")";
      errorCb(msg.dump(), ss.str());
    } else
      throw;
  }
}

void
Dispatcher::dispatchEvent(const nlohmann::json& msg)
{
  auto messageId = msg.at("message-id").get<std::string>();

  if(messageId == "ready") {
    if(readyCb)
      readyCb(msg.at("version"));
  } else if(messageId == "attach") {
    if(attachCb)
      attachCb({
        msg.at("dongle-id").get<DongleId>(),
        msg.at("name").get<std::string>(),
        msg.at("serial").get<std::string>(),
        msg.at("version").get<std::string>()
      });
  } else if(messageId == "detach") {
    if(detachCb)
      detachCb(msg.at("dongle-id").get<DongleId>());
  } else if(messageId == "connection-attempt") {
    if(connectionAttemptCb)
      connectionAttemptCb(msg.at("dongle-id").get<DongleId>(), msg.at("address").get<std::string>());
  } else if(messageId == "pairing-list") {
    std::vector<Pairing> pairings;

    for(auto& x: msg.at("pairings")) {
      pairings.push_back({
        x.at("pairing-id").get<PairingId>(),
        x.at("name").get<std::string>(),
        x.at("address").get<std::string>(),
        x.at("connected").get<bool>()
      });
    }

    if(pairingListCb)
      pairingListCb(msg.at("dongle-id").get<DongleId>(), pairings);
  } else if(messageId == "connected") {
    if(connectedCb)
      connectedCb(msg.at("dongle-id").get<DongleId>(), msg.at("pairing-id").get<PairingId>());
  } else if(messageId == "connect-timeout") {
    if(connectTimeoutCb)
      connectTimeoutCb(msg.at("dongle-id").get<DongleId>(), msg.at("pairing-id").get<PairingId>());
  } else if(messageId == "disconnected") {
    if(disconnectedCb)
      disconnectedCb(msg.at("dongle-id").get<DongleId>(), msg.at("pairing-id").get<PairingId>());
  } else if(messageId == "disconnect-timeout") {
    if(disconnectTimeoutCb)
      disconnectTimeoutCb(msg.at("dongle-id").get<DongleId>(), msg.at("pairing-id").get<PairingId>());
  } else if(messageId == "pairing-complete") {
    if(pairingCompleteCb)
      pairingCompleteCb(msg.at("dongle-id").get<DongleId>(), msg.at("pairing-id").get<PairingId>());
  } else if(messageId == "pairing-timeout") {
    if(pairingTimeoutCb)
      pairingTimeoutCb(msg.at("dongle-id").get<DongleId>(), msg.at("address").get<std::string>());
  } else if(messageId == "pairing-rejected") {
    if(pairingRejectedCb)
      pairingRejectedCb(msg.at("dongle-id").get<DongleId>(), msg.at("address").get<std::string>());
  } else if(messageId == "search-result") {
    if(searchResultCb)
      searchResultCb(msg.at("dongle-id").get<DongleId>(),
                     msg.at("address").get<std::string>(),
                     msg.at("name").get<std::string>(),
                     msg.at("signal-strength").get<SignalStrength>());
  } else if(messageId == "search-complete") {
    if(searchCompleteCb)
      searchCompleteCb(msg.at("dongle-id").get<DongleId>());
  } else {
    if(errorCb)
      errorCb(msg.dump(), "unknown message id: "s + messageId);
  }
}

void
Dispatcher::dispatchAck(const nlohmann::json& msg)
{
  if(ackCb)
    ackCb(msg.at("message-id").get<std::string>());
}

void
Dispatcher::dispatchNack(const nlohmann::json& msg)
{
  if(nackCb)
    nackCb(msg.at("message-id").get<std::string>(),
           msg.at("reason-id").get<size_t>(),
           msg.at("reason-text").get<std::string>());
}

} // namespace JdtMsg