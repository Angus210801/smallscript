#include <cstdlib>

#include "JdtProxy.h"

#include <syslog.h>
#include <unistd.h>
#include <limits.h>

using json = nlohmann::json;

JdtProxy::JdtProxy()
{
}

JdtProxy::~JdtProxy() {
  jdt.getStatus();
}

bool
JdtProxy::start(const std::string& command)
{
  std::string cmd = command;

  if(cmd.empty())
    cmd = locateJdtBinary();

  return jdt.start(cmd);
}

bool
JdtProxy::recvMsg(nlohmann::json& msg)
{
  bool res = false;
  std::string line;

  if(jdt.getLine(line)) {
    res = true;
    msg.clear();

    if(!line.empty()) {
      try {
        msg = json::parse(line);
      } catch(std::exception& e) {
        msg.clear();
        res = false;
      }
    }
  }

  return res;
}

bool
JdtProxy::sendMsg(const nlohmann::json& msg)
{
  return jdt.putLine(msg.dump());
}

std::string
JdtProxy::locateJdtBinary()
{
  std::string res;

  // try to locate the jdt binary in one of these locations:
  //
  //   1. In same directory as current executable.
  //
  //   2. If not found, then assume that we are executing from a build
  //      directory in the demo tree. Try to find a bin directory a
  //      couple of levels up from the program directory.
  //
  //   3. /usr/bin
  //
  //   4. /usr/local/bin

  std::string curProgDir = currentProgramDirectoryPath();
  std::string jdtBinary = "jdt";

  std::vector<std::string> paths = {
    curProgDir + "/" + jdtBinary,
    curProgDir + "/../bin/" + jdtBinary,
    curProgDir + "/../../bin/" + jdtBinary,
    "/usr/bin/" + jdtBinary,
    "/usr/local/bin/" + jdtBinary
  };

  for(auto& p: paths) {
    std::string test = "test -x " + p;

    if(system(test.c_str()) == 0) {
      res = p;
      break;
    }
  }

  return res;
}

std::string
JdtProxy::currentProgramFilePath()
{
  std::string res;
  char path[PATH_MAX];
  ssize_t count = readlink("/proc/self/exe", path, PATH_MAX);

  if(count == -1) {
    syslog(LOG_ERR, "cannot determine program path: readlink fails: %s\n", strerror(errno));
  } else if(count > PATH_MAX) {
    syslog(LOG_ERR, "readlink returns count > PATH_MAX: %ld\n", static_cast<long>(count));
  } else {
    path[count] = '\0';
    res = path;
  }

  return res;
}

std::string
JdtProxy::currentProgramDirectoryPath()
{
  std::string res = currentProgramFilePath();
  res.erase(res.rfind('/'));
  return res;
}
