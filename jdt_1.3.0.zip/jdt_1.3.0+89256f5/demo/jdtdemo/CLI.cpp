#include "CLI.h"

#include <sstream>

#include <readline/readline.h>
#include <readline/history.h>

CLI::CLI()
{
}

CLI::~CLI()
{
  if(thread.joinable())
    thread.join();
}

bool
CLI::addCommand(const std::string& cmd, const CommandHandler& handler)
{
  Guard lk(mutex);
  auto it = commands.find(cmd);

  if(it != commands.end())
    return false;

  commands[cmd] = handler;

  return true;
}

void
CLI::setDoneCallback(DoneCallback cb)
{
  Guard lk(mutex);
  doneCb = cb;
}

void
CLI::setErrorCallback(ErrorCallback cb)
{
  Guard lk(mutex);
  errorCb = cb;
}

void
CLI::setPrompt(const std::string& newPrompt)
{
  prompt = newPrompt;
}

void
CLI::start()
{
  Guard lk(mutex);

  if(!started) {
    started = true;
    thread = std::thread([this] { commandLoop(); });
  }
}

void
CLI::commandLoop()
{
  bool done = false;
  char *input;

  //rl_bind_key('\t', rl_complete);

  while(!done) {
    if((input = readline(prompt.c_str())) != nullptr) {
      Guard lk(mutex);

      std::string cmdLine = input;
      free(input);

      if(!cmdLine.empty()) {
        ParsedCommand cmd;
        add_history(cmdLine.c_str());

        if(splitCommandLine(cmdLine, cmd)) {
          done = emitCommand(cmd);

          if(done)
            emitDone();
        }
      }
    } else {
      Guard lk(mutex);

      printf("\n");
      emitDone();
      done = true;
    }
  }
}

bool
CLI::splitCommandLine(std::string line, ParsedCommand& cmd)
{
  bool res = true;
  enum class State { Init, InToken, InString, InWhiteSpace };
  State s = State::Init;
  std::stringstream token;

  // trim trailing white space
  const char* ws = " \t\n\r\f\v";
  line.erase(line.find_last_not_of(ws) + 1);
  line.erase(0, line.find_first_not_of(ws));

  for(auto c: line) {
    switch(s) {
    case State::Init:
      if(c == ' ') {
        s = State::InWhiteSpace;
      } else if(c == '"') {
        s = State::InString;
      } else {
        token << c;
        s = State::InToken;
      }
      break;

    case State::InToken:
      if(c == ' ') {
        cmd.push_back(token.str());
        token.str("");
        s = State::InWhiteSpace;
      } else if(c == '"') {
        s = State::InString;
      } else {
        token << c;
      }
      break;

    case State::InString:
      if(c == '"') {
        cmd.push_back(token.str());
        token.str("");
        s = State::Init;
      } else {
        token << c;
      }
      break;

    case State::InWhiteSpace:
      if(c == '"') {
        s = State::InString;
      } else if(c != ' ') {
        token << c;
        s = State::InToken;
      }
      break;
    }
  }

  if(s == State::InToken) {
    cmd.push_back(token.str());
    token.str("");
    s = State::Init;
  } else if(s == State::InString) {
    emitError(ErrorType::ParseError, "Unterminated string", line);
    cmd.clear();
    res = false;
  }

  return res;
}

bool
CLI::emitCommand(const ParsedCommand& cmd)
{
  bool res = false;
  auto it = commands.find(cmd[0]);

  if(it != commands.end())
    res = it->second(cmd);
  else
    emitError(ErrorType::UnknownCommand, "Unknown command", cmd[0]);

  return res;
}

void
CLI::emitDone()
{
  if(doneCb)
    doneCb();
}

void
CLI::emitError(ErrorType errorType, const std::string& msg, const std::string& line)
{
  if(errorCb)
    errorCb(errorType, msg, line);
}