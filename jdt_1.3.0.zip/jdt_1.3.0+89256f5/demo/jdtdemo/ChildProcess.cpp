#include "ChildProcess.h"
#include <cstdlib>
#include <cstring>
#include <cerrno>
#include <unistd.h>
#include <syslog.h>
#include <wait.h>

ChildProcess::ChildProcess()
{
}

ChildProcess::~ChildProcess()
{
  if(ifd)
    close(ifd);

  if(ofd)
    close(ofd);

  getStatus();
}

bool
ChildProcess::start(const std::string& command)
{
  if(command.empty())
    return false;

  if(command.substr(0, 6) == "ssh://") {
    // A command can be started on another host using ssh. Use an URL like this:
    //
    //   ssh://hostpart:commandPart
    //
    // The host part and commandPart are passed directly to /usr/bin/ssh.

    return doFork([&] {
      unsigned long colonPos = command.find_first_of(':', 6);
      std::string hostPart = command.substr(6, colonPos - 6);
      std::string cmdPart  = command.substr(colonPos+1);

      execl("/usr/bin/ssh", "/usr/bin/ssh", hostPart.c_str(), cmdPart.c_str(), nullptr);
      syslog(LOG_ERR, "execl: %s", strerror(errno));
      return false;
    });
  } else {
    // The command is assumed to be a path to a binary to execute locally.

    return doFork([&] {
      execl(command.c_str(), command.c_str(), nullptr);
      syslog(LOG_ERR, "execl: %s", strerror(errno));
      return false;
    });
  }
}

bool
ChildProcess::doFork(const std::function<bool()>& childCallback)
{
  int iPipe[2], oPipe[2];

  if(pipe(iPipe) == -1) {
    syslog(LOG_ERR, "iPipe: %s", strerror(errno));
    return false;
  }

  if(pipe(oPipe) == -1) {
    syslog(LOG_ERR, "oPipe: %s", strerror(errno));
    return false;
  }

  if((pid = fork()) == -1) {
    syslog(LOG_ERR, "fork: %s", strerror(errno));
    return false;
  }

  if(pid == 0) {
    close(iPipe[1]);
    dup2(iPipe[0], 0);

    close(oPipe[0]);
    dup2(oPipe[1], 1);

    // the childCallback should execl() and never return..
    return childCallback();
  }

  close(iPipe[0]);
  close(oPipe[1]);

  ifd = oPipe[0];
  ofd = iPipe[1];

  return true;
}

bool
ChildProcess::getLine(std::string& line)
{
  char c;
  ssize_t n;

  line.clear();

  while((n = read(ifd, &c, 1)) == 1) {
    if(c == '\r' || c == '\n')
      break;
    else
      line.push_back(c);
  }

  return (!line.empty() || (n == 1));
}

bool
ChildProcess::putLine(const std::string& line)
{
  if(write(ofd, line.c_str(), line.size()) == -1) {
    syslog(LOG_ERR, "write: %s", strerror(errno));
    return false;
  }

  if(write(ofd, "\n", 1) == -1) {
    syslog(LOG_ERR, "write: %s", strerror(errno));
    return false;
  }

  return true;
}

int
ChildProcess::getStatus()
{
  if(!waitDone) {
    if(waitpid(pid, &status, 0) == -1) {
      syslog(LOG_ERR, "waitpid: %s", strerror(errno));
      return -1;
    }

    waitDone = true;
  }

  return status;
}