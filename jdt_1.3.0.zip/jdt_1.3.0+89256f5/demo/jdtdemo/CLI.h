#ifndef REPL_H
#define REPL_H

#include <functional>
#include <thread>
#include <mutex>
#include <vector>
#include <map>

class CLI
{
public:
  CLI();
  virtual ~CLI();

public:
  enum class ErrorType { ParseError, UnknownCommand};

  using ParsedCommand  = std::vector<std::string>;
  using CommandHandler = std::function<bool(const ParsedCommand& cmd)>;
  using DoneCallback   = std::function<void()>;
  using ErrorCallback  = std::function<void(ErrorType type, const std::string& msg, const std::string& line)>;

public:
  bool addCommand(const std::string& cmd, const CommandHandler& handler);
  void setDoneCallback(DoneCallback cb);
  void setErrorCallback(ErrorCallback cb);
  void setPrompt(const std::string& newPrompt);
  void start();

private:
  using CommandMap = std::map<std::string, CommandHandler>;
  using Mutex = std::mutex;
  using Guard = std::lock_guard<Mutex>;

private:
  void commandLoop();
  bool splitCommandLine(std::string line, ParsedCommand& cmd);

private:
  bool emitCommand(const ParsedCommand& cmd);
  void emitDone();
  void emitError(ErrorType errorType, const std::string& msg, const std::string& line);

private:
  Mutex         mutex;
  std::thread   thread;
  bool          started = false;
  CommandMap    commands;
  DoneCallback  doneCb;
  ErrorCallback errorCb;
  std::string   prompt = "> ";
};

#endif //REPL_H
